# 第二阶段：ROS 2 双向 Topic 公网测试

## 1. 目标与边界

本阶段只验证 ROS 2 Jazzy 的不同格式 Topic 能通过第一阶段的 WebSocket 公网中继双向传输。
RK3576（“猫”）仅承担通信，不接树莓派控制接口，不发送真实车辆控制。

```text
PC ROS 2 <---> pc_ros2_bridge.py <---> 云端 relay_server.py
                                      <---> rk3576_ros2_bridge.py <---> RK3576 ROS 2
```

云服务器继续运行第一阶段的 `relay_server.py`，无需修改。

## 2. 测试 Topic

两边故意使用不同消息格式：

| 方向 | Topic | ROS 2 类型 |
| --- | --- | --- |
| PC -> RK3576 | `/pc_to_cat` | `std_msgs/msg/String` |
| RK3576 -> PC | `/cat_to_pc` | `geometry_msgs/msg/Vector3` |

发送端 bridge 订阅本机 Topic，转换为 JSON 后发送；接收端 bridge 校验 JSON，再以原 ROS
类型发布到同名 Topic。两个 Topic 的方向固定，所以不会在本机形成回送环路。

## 3. 环境准备

PC 和 RK3576 都使用 Ubuntu 24.04、ROS 2 Jazzy，并已安装：

```bash
sudo apt install ros-jazzy-ros-base ros-jazzy-geometry-msgs python3-websockets
source /opt/ros/jazzy/setup.bash
```

如果每次打开终端都要使用 ROS 2，可把 `source` 命令加入 shell 启动文件。

## 4. 启动

保持云服务器上的第一阶段中继运行：

```powershell
py -3.11 relay_server.py
```

PC（Wi-Fi）运行：

```bash
source /opt/ros/jazzy/setup.bash
python3 pc_ros2_bridge.py
```

RK3576（手机热点，ROS 2 Humble）使用标准 ROS 包运行：

```bash
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch rk3576_ws_bridge bridge.launch.py
```

脚本默认连接 `8.134.118.29`。也可以用命令行临时覆盖完整地址，例如：

```bash
python3 pc_ros2_bridge.py ws://8.134.118.29:8770
ros2 run rk3576_ws_bridge bridge_node --ros-args \
  -p server_uri:=ws://8.134.118.29:8771
```

## 5. 双向验收

在 PC 的另一个 ROS 2 终端持续发送字符串：

```bash
ros2 topic pub -r 1 /pc_to_cat std_msgs/msg/String "{data: 'hello from pc'}"
```

在 RK3576 的另一个终端检查是否还原为 ROS Topic：

```bash
ros2 topic echo /pc_to_cat std_msgs/msg/String
```

在 RK3576 的另一个终端持续发送三维向量：

```bash
ros2 topic pub -r 1 /cat_to_pc geometry_msgs/msg/Vector3 "{x: 1.0, y: 2.0, z: 3.0}"
```

在 PC 的另一个终端检查：

```bash
ros2 topic echo /cat_to_pc geometry_msgs/msg/Vector3
```

两边的 `echo` 都持续出现对端发送的数据，即表示第二阶段基本链路通过。

## 6. 当前 JSON 封装

PC 的字符串 Topic 示例：

```json
{"source":"pc","type":"ros_topic","seq":1,"timestamp":1788364800000,"topic":"/pc_to_cat","msg_type":"std_msgs/msg/String","data":{"data":"hello from pc"}}
```

RK3576 的向量 Topic 示例：

```json
{"source":"rk3576","type":"ros_topic","seq":1,"timestamp":1788364800010,"topic":"/cat_to_pc","msg_type":"geometry_msgs/msg/Vector3","data":{"x":1.0,"y":2.0,"z":3.0}}
```

该 schema 只用于基本链路测试。后续明确真实 Topic 和消息类型后再定义正式映射。

## 7. 注意事项

- 中继不缓存消息。对端 bridge 离线时发送的数据会丢弃，这是本阶段的预期行为。
- bridge 断线后每 2 秒自动重连；队列只保留最新一条本地消息，避免重连后发送大量过期数据。
- 接收端只接受本阶段约定的来源、Topic 和消息类型，其他 JSON 会被忽略并记录警告。
- ROS 2 DDS 只在每台机器本地工作，跨公网的数据实际走 WebSocket，不要求两台机器能通过
  DDS 互相发现。
- 当前仍是明文、无认证测试链路，不应承载真实控制指令。
