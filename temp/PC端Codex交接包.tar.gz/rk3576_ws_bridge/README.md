# RK3576 ROS 2 WebSocket Bridge

本包运行于当前 RK3576（Ubuntu 22.04 / ROS 2 Humble），用于第二阶段基本链路测试。

## 构建

在工作空间根目录 `/home/cat/Desktop/SBGDUT` 执行：

```bash
source /opt/ros/humble/setup.bash
colcon build --packages-select rk3576_ws_bridge --symlink-install
source install/setup.bash
```

## 启动

配置文件为 `config/bridge.yaml`，默认连接云服务器 `ws://8.134.118.29:8771`：

```bash
ros2 launch rk3576_ws_bridge bridge.launch.py
```

也可临时覆盖参数：

```bash
ros2 run rk3576_ws_bridge bridge_node --ros-args \
  -p server_uri:=ws://8.134.118.29:8771 \
  -p outbound_topic:=/cat_to_pc \
  -p inbound_topic:=/pc_to_cat
```

## 本机接口

- 订阅 `/cat_to_pc`（`geometry_msgs/msg/Vector3`），封装为 JSON 发往 PC。
- 接收 PC 的 JSON，还原并发布 `/pc_to_cat`（`std_msgs/msg/String`）。

本机发送测试：

```bash
ros2 topic pub -r 1 /cat_to_pc geometry_msgs/msg/Vector3 \
  "{x: 1.0, y: 2.0, z: 3.0}"
```

等待 PC 侧联调时检查接收结果：

```bash
ros2 topic echo /pc_to_cat std_msgs/msg/String
```

## 测试

```bash
colcon test --packages-select rk3576_ws_bridge
colcon test-result --verbose
```
